<div class="tab-pane {{{ $status ?? '' }}}" id="{{ $tab }}">
    <h1>
     
    </h1>
    <br />

                                <a href="{{ url('/tasks/create') }}" class="btn btn-sm btn-primary" type="button">
                                    <span class="fa fa-plus" aria-hidden="true"></span> New Task
                                </a>

    <br /><br /><br />

    <div class="table-responsive">
        <table class="table table-striped task-table table-condensed">
            <thead>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th colspan="3">Status</th>
            </thead>
            <tbody>
                @foreach ($tasks as $task)
                    @include('tasks.partials.task-row')
                @endforeach
            </tbody>
        </table>
    </div>
</div>
