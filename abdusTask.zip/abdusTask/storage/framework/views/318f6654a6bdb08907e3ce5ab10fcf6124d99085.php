<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">

                <!-- Display Validation Errors -->
                <?php echo $__env->make('common.status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="panel panel-default">
                    <div class="panel-heading">
                        Editing Task <strong><?php echo e($task->name); ?></strong>
                    </div>
                    <div class="panel-body">

                        <?php echo Form::model($task, array('action' => array('TasksController@update', $task->id), 'method' => 'PUT')); ?>


                            <div class="form-group row">
                                <?php echo Form::label('name', 'Task Name', array('class' => 'col-sm-3 col-sm-offset-1 control-label text-right')); ?>

                                <div class="col-sm-6">
                                    <?php echo Form::text('name', null, array('class' => 'form-control')); ?>

                                </div>
                            </div>


                            <div class="form-group row">
                                <?php echo Form::label('description', 'Task Description', array('class' => 'col-sm-3 col-sm-offset-1 control-label text-right')); ?>

                                <div class="col-sm-6">
                                    <?php echo Form::textarea('description', null, array('class' => 'form-control')); ?>

                                </div>
                            </div>


                            <!-- Task Status -->

                            <div class="form-group row">
                                <label for="status" class="col-sm-3 col-sm-offset-1 control-label text-right">Status</label>
                                <div class="col-sm-6">
                                    <div class="checkbox">
                                        <label for="status">
                                            <?php echo Form::checkbox('completed', 1, null, ['id' => 'status']); ?> Complete
                                        </label>
                                    </div>
                                </div>
                            </div>


                            <!-- Add Task Button -->
                            <div class="form-group row">
                                <div class="col-sm-offset-4 col-sm-6">
                                     <?php echo e(Form::button('<span class="fa fa-save fa-fw" aria-hidden="true"></span> <span class="hidden-xxs">Save</span> <span class="hidden-xs">Changes</span>', array('type' => 'submit', 'class' => 'btn btn-success btn-block'))); ?>

                                </div>
                            </div>


                        <?php echo Form::close(); ?>


                    </div>
                    <div class="panel-footer">
                        <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-sm btn-info" type="button">
                            <span class="fa fa-reply" aria-hidden="true"></span> Back to Tasks
                        </a>

                        <?php echo Form::open(array('class' => 'form-inline pull-right', 'method' => 'DELETE', 'route' => array('tasks.destroy', $task->id))); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(Form::button('<span class="fa fa-trash fa-fw" aria-hidden="true"></span> <span class="hidden-xxs">Delete</span> <span class="hidden-sm hidden-xs">Task</span>', array('type' => 'submit', 'class' => 'btn btn-danger'))); ?>

                        <?php echo Form::close(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\abdus-task\New folder\laravel-tasks-master\resources\views/tasks/edit.blade.php ENDPATH**/ ?>