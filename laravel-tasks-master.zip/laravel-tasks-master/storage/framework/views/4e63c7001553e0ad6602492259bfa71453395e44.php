<tr>

    <!-- Task Id -->
    <td class="table-text">
        <?php echo e($task->id); ?>

    </td>

    <!-- Task Name -->
    <td class="table-text">
        <?php echo e($task->name); ?>

    </td>

    <!-- Task Description -->
    <td>
        <?php echo e($task->description); ?>

    </td>

    <!-- Task Status -->
    <td>

        <?php if($task->completed === 1): ?>

            <span class="label label-success">
                Complete
            </span>

        <?php else: ?>

            <span class="label label-default">
                Incomplete
            </span>

        <?php endif; ?>

    </td>

    <!-- Task Status Checkbox -->
    <td>
        
    </td>

    <!-- Task Edit Icon -->
    <td>
        <a href="<?php echo e(route('tasks.edit', $task->id)); ?>" class="pull-right">
            <span class="fa fa-pencil fa-fw" aria-hidden="true"></span>
            <span class="sr-only">Edit Task</span>
        </a>
    </td>

    <td>
        <a href="" class="pull-right">
            <span style="color: red;" onclick="return confirm('Are you sure you want to delete?')" class="fa fa-trash fa-fw" aria-hidden="true"></span>
            <span class="sr-only">Delete Task</span>
        </a>
    </td>
</tr><?php /**PATH D:\xampp\htdocs\abdus-task\New folder\laravel-tasks-master\resources\views/tasks/partials/task-row.blade.php ENDPATH**/ ?>