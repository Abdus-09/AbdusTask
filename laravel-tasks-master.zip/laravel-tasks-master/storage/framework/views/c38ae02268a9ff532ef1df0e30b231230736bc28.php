<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-sm-offset-1 col-sm-10">

            <!-- Display Validation Errors -->
            <?php echo $__env->make('common.status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Current Tasks -->
            <?php if(count($tasks) > 0): ?>

                <div class="panel panel-default">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-12">

                                <?php if(Request::is('tasks-all')): ?>
                                    All Tasks
                                <?php elseif(Request::is('tasks-incomplete')): ?>
                                    Incomplete Tasks
                                <?php elseif(Request::is('tasks-complete')): ?>
                                   Complete Tasks
                                <?php else: ?>
                                    No Tasks
                                <?php endif; ?>

                                <div class="pull-right">

                                    <a href="<?php echo e(url('/tasks-all')); ?>" class="btn btn-sm btn-default <?php echo e(Request::is('tasks-all') ? 'active' : ''); ?>" type="button">
                                        <span class="fa fa-tasks" aria-hidden="true"></span> <span class="hidden-xs">All</span>
                                    </a>
                                    <a href="<?php echo e(url('/tasks-incomplete')); ?>" class="btn btn-sm btn-default <?php echo e(Request::is('tasks-incomplete') ? 'active' : ''); ?>" type="button">
                                        <span class="fa fa-square-o" aria-hidden="true"></span> <span class="hidden-xs">Incomplete</span>
                                    </a>
                                    <a href="<?php echo e(url('/tasks-complete')); ?>" class="btn btn-sm btn-default <?php echo e(Request::is('tasks-complete') ? 'active' : ''); ?>" type="button">
                                        <span class="fa fa-check-square-o" aria-hidden="true"></span> <span class="hidden-xs">Complete</span>
                                    </a>

                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-striped task-table table-condensed">
                                <thead>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th colspan="3">Status</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo $__env->make('tasks.partials.task-row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="panel-footer">
                        <div class="row">
                            <div class="col-xs-12">
                                <a href="<?php echo e(url('/tasks/create')); ?>" class="btn btn-sm btn-primary pull-right" type="button">
                                    <span class="fa fa-plus" aria-hidden="true"></span> New Task
                                </a>
                            </div>
                        </div>
                    </div>

                </div>

            <?php else: ?>

                <div class="panel panel-default">
                    <div class="panel-heading">
                        Create New Task
                    </div>
                    <div class="panel-body">

                        <?php echo $__env->make('tasks.partials.create-task', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>
                </div>

            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('table').DataTable();
        } );
    </script>


<script type="text/javascript">
    jQuery(document).ready(function ($) {
        $('#tabs').tab();
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\abdus-task\New folder\laravel-tasks-master\resources\views/tasks/filtered.blade.php ENDPATH**/ ?>