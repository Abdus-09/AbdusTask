<!-- New Task Form -->
<?php echo Form::model(new App\Task, ['route' => ['tasks.store'], 'class'=>'form-horizontal', 'role' => 'form']); ?>


    <!-- Task Name -->
    <div class="form-group">
        <label for="task-name" class="col-sm-3 control-label">Task Name</label>

        <div class="col-sm-6">
            <input type="text" name="name" id="task-name" class="form-control" value="<?php echo e(old('task')); ?>">
        </div>
    </div>

    <!-- Task Description -->
    <div class="form-group">
        <label for="task-description" class="col-sm-3 control-label">Description</label>

        <div class="col-sm-6">
            <textarea name="description" id="task-description" class="form-control" value="<?php echo e(old('task')); ?>" maxlength="155"></textarea>
        </div>
    </div>

    <!-- Add Task Button -->
    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-6">
             <?php echo e(Form::button('<span class="fa fa-plus fa-fw" aria-hidden="true"></span> Create Task', array('type' => 'submit', 'class' => 'btn btn-default'))); ?>

        </div>
    </div>

<?php echo Form::close(); ?><?php /**PATH D:\xampp\htdocs\abdus-task\New folder\laravel-tasks-master\resources\views/tasks/partials/create-task.blade.php ENDPATH**/ ?>