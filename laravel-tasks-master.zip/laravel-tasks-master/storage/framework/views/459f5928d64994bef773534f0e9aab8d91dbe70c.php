<div class="tab-pane <?php echo e($status ?? ''); ?>" id="<?php echo e($tab); ?>">
    <h1>
     
    </h1>
    <br />

                                <a href="<?php echo e(url('/tasks/create')); ?>" class="btn btn-sm btn-primary" type="button">
                                    <span class="fa fa-plus" aria-hidden="true"></span> New Task
                                </a>

    <br /><br /><br />

    <div class="table-responsive">
        <table class="table table-striped task-table table-condensed">
            <thead>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th colspan="3">Status</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('tasks.partials.task-row', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\abdus-task\New folder\laravel-tasks-master\resources\views/tasks/partials/task-tab.blade.php ENDPATH**/ ?>